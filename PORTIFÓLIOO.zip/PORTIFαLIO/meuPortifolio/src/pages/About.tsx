import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const About = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-pink-700">
          SOBRE MIM
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Foto */}
          <div className="lg:col-span-5 h-full">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="relative h-full"
            >
              <div className="rounded-lg overflow-hidden border-2 border-[#ff007f] shadow-lg shadow-pink-500/10 h-full">
                <img
                  src="/minha-foto.jpeg"
                  alt="Foto de perfil"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-pink-200">ISABELA ETORE</h3>
                    <p className="text-pink-100 opacity-80">Desenvolvedora FrontEnd & BackEnd</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-pink-500/10 rounded-full blur-xl z-[-1]"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-pink-500/10 rounded-full blur-xl z-[-1]"></div>
            </motion.div>
          </div>

          {/* Texto */}
          <div className="lg:col-span-7 h-full">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="h-full"
            >
              <Card className="bg-[#ff007f] border-[#ff007f] h-full flex flex-col">
                <CardContent className="p-6 text-white flex-grow flex flex-col">
                  <h2 className="text-2xl font-bold mb-4">OLÁ, EU SOU A ISABELA!</h2>

                  <div className="space-y-4">
                    <p>
                      Olá! Meu nome é Isabela Etore Lopes, tenho 16 anos e sou uma estudante apaixonada
                      por tecnologia, comunicação e criatividade. Atualmente, estou cursando Tecnologia
                      da Informação, onde venho desenvolvendo habilidades técnicas e trabalhando em
                      projetos práticos que reforçam meu interesse por soluções digitais. Minha trajetória
                      já conta com mais de 5 certificados em áreas complementares, incluindo Economia
                      Circular, LGPD (Lei Geral de Proteção de Dados), Desvendando o 5G, Segurança
                      no Trabalho, além de dois cursos da FreeCodeCamp voltados para tecnologia. Essa
                      formação me permite ter uma visão ampla e atualizada do mercado, conectando inovação,
                      sustentabilidade e responsabilidade digital.
                    </p>

                    <p>
                      Durante 7 anos, estudei inglês na escola CNA, o que me proporcionou uma base
                      sólida na língua e a capacidade de me comunicar com fluência em ambientes acadêmicos
                      e profissionais. Tenho ainda orgulho de destacar minha nota 920 na redação do ENEM
                      2023, mesmo participando como treineira — uma conquista que reforça minha capacidade
                      de argumentação, escrita e interpretação de temas contemporâneos.
                    </p>

                    <p>
                      Além do mundo dos estudos, sou uma pessoa curiosa, comunicativa e que valoriza os
                      momentos em família. Gosto de aprender com diferentes experiências e acredito que
                      boas ideias surgem de boas conexões. Por isso, estou em busca de oportunidades
                      na área de Publicidade e Propaganda, onde posso unir minha paixão por tecnologia,
                      linguagem e criatividade para desenvolver campanhas, conteúdos e estratégias de impacto.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">HABILIDADES</h3>
                        <ul className="list-disc list-inside space-y-1">
                          <li>React & TypeScript</li>
                          <li>HTML5 & CSS3</li>
                          <li>UI/UX Design</li>
                          <li>Desenvolvimento Responsivo</li>
                          <li>Acessibilidade Web</li>
                        </ul>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold mb-2">INTERESSES</h3>
                        <ul className="list-disc list-inside space-y-1">
                          <li>Literatura Fantástica</li>
                          <li>Design de Interfaces</li>
                          <li>Animações Web</li>
                          <li>Desenvolvimento de Sites</li>
                          <li>Novas Tecnologias</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default About;
