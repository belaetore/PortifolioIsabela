
import { motion } from "framer-motion";

const Projects = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-pink-700">
          PROJETOS
        </h1>
        
        <div className="text-center py-12">
          <p className="text-gray-700 max-w-2xl mx-auto">
            Esta seção está em construção. Em breve adicionarei mais informações sobre mim.
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default Projects;
