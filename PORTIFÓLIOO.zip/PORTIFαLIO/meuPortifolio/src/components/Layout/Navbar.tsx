
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const isMobile = useIsMobile();
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  const toggleMenu = () => setIsOpen(!isOpen);
  
  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      scrolled ? "bg-black/80 backdrop-blur-md py-3" : "bg-transparent py-4"
    }`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="w-10"></div> {/* Empty div for spacing */}
        
        {isMobile ? (
          <>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMenu}
              className="text-pink-200 hover:text-pink-100"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
            
            {isOpen && (
              <div className="fixed inset-0 top-16 bg-black/95 flex flex-col items-center pt-10 animate-fade-in">
                <NavLinks closeMenu={() => setIsOpen(false)} />
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-6">
            <NavLinks />
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLinks = ({ closeMenu = () => {} }) => {
  const navItems = [
    { label: "Home", path: "/" },
    { label: "Sobre", path: "/about" },
    { label: "Certificados", path: "/certificates" },
    { label: "Projetos", path: "/projects" },
    { label: "Contato", path: "/contact" },
  ];
  
  return (
    <>
      {navItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          className="text-pink-600 hover:text-pink-500 relative group px-2 py-1"
          onClick={closeMenu}
        >
          {item.label}
          <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-pink-500 transition-all duration-300 group-hover:w-full"></span>
        </Link>
      ))}
      <Button 
        variant="outline" 
        className="ml-4 text-pink-600 border-pink-500 hover:bg-pink-50"
        asChild
      >
        <a href="/MEU FUTURO CURRÍCULO.pdf" download>Download CV</a>
      </Button>
    </>
  );
};

export default Navbar;
